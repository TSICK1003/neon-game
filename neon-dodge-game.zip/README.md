# NEON DODGE

브라우저에서 바로 실행되는 장애물 피하기 웹게임입니다.

## 실행
`index.html` 파일을 Chrome, Edge 등 브라우저로 열면 됩니다.

## 조작
- 왼쪽/오른쪽 방향키 또는 A/D
- 게임 시작, 일시정지, 다시하기 버튼
- 모바일에서는 화면 아래 방향 버튼 사용

## GitHub Pages로 공개하기
1. GitHub에 로그인하고 새 Public Repository를 만듭니다.
2. `index.html`을 저장소 루트에 업로드합니다.
3. 저장소의 Settings → Pages로 이동합니다.
4. Build and deployment에서 Deploy from a branch를 선택합니다.
5. Branch를 `main`, 폴더를 `/(root)`로 선택하고 Save를 누릅니다.
6. 배포가 끝나면 Pages 화면에 표시되는 주소로 접속합니다.
